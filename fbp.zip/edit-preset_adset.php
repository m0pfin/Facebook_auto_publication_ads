<?php
				include "includes/header.php";
				$data=[];

				$act = $_GET['act'];
				if($act == "edit"){
					$id = $_GET['id'];
					$preset_adset = getById("preset_adset", $id);
				}
				?>

				<form method="post" action="save.php" enctype='multipart/form-data'>
					<fieldset>
						<legend class="hidden-first">Add New Preset_adset</legend>
						<input name="cat" type="hidden" value="preset_adset">
						<input name="id" type="hidden" value="<?=$id?>">
						<input name="act" type="hidden" value="<?=$act?>">
				
							<label>Name</label>
							<input class="form-control" type="text" name="name" value="<?=$preset_adset['name']?>" /><br>
							
							<label>Daily budget</label>
							<input class="form-control" type="text" name="daily_budget" value="<?=$preset_adset['daily_budget']?>" /><br>
							
							<label>Start time</label>
							<input class="form-control" type="text" name="start_time" value="<?=$preset_adset['start_time']?>" /><br>
							
							<label>End time</label>
							<input class="form-control" type="text" name="end_time" value="<?=$preset_adset['end_time']?>" /><br>
							
							<label>Bid strategy</label>
							<input class="form-control" type="text" name="bid_strategy" value="<?=$preset_adset['bid_strategy']?>" /><br>
							
							<label>Billing event</label>
							<input class="form-control" type="text" name="billing_event" value="<?=$preset_adset['billing_event']?>" /><br>
							
							<label>Optimization goal</label>
							<input class="form-control" type="text" name="optimization_goal" value="<?=$preset_adset['optimization_goal']?>" /><br>
							
							<label>Campaign id</label>
							<input class="form-control" type="text" name="campaign_id" value="<?=$preset_adset['campaign_id']?>" /><br>
							
							<label>Targeting geo countries</label>
							<input class="form-control" type="text" name="targeting_geo_countries" value="<?=$preset_adset['targeting_geo_countries']?>" /><br>
							
							<label>Custom event type</label>
							<input class="form-control" type="text" name="custom_event_type" value="<?=$preset_adset['custom_event_type']?>" /><br>
							
							<label>Pixel id</label>
							<input class="form-control" type="text" name="pixel_id" value="<?=$preset_adset['pixel_id']?>" /><br>
							
							<label>Status</label>
							<input class="form-control" type="text" name="status" value="<?=$preset_adset['status']?>" /><br>
							
							<label>Ads id</label>
							<input class="form-control" type="text" name="ads_id" value="<?=$preset_adset['ads_id']?>" /><br>
							<br>
					<input type="submit" value=" Save " class="btn btn-success">
					</form>
					<?php include "includes/footer.php";?>
				