<?php
/**
 * Created by PhpStorm.
 * User: m0pfin
 * Date: 01.07.2020
 * Time: 23:36
 */

var_dump($_POST);
print_r($_FILES);