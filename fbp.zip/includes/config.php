<?php
/**
 * Created by PhpStorm.
 * User: m0pfin
 * Date: 24.06.2020
 * Time: 02:02
 */

return [
    'host' => 'localhost',
    'db_name' => 'fbads',
    'user' => 'root',
    'password' => 'root',
    'charset' => 'utf8'
];