<?php
				include "includes/header.php";
				?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><a class="btn btn-primary" href="edit-ad_account.php?act=add"> <i class="glyphicon glyphicon-plus-sign"></i> Add New Ad account</a></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><i class="fab fa-facebook-f"> </i> Ad Accounts</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
    <!-- Default box -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Всего аккаунтов <?php echo counting("ad_account", "id");?></h3>

            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                    <i class="fas fa-minus"></i></button>
                <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
                    <i class="fas fa-times"></i></button>
            </div>
        </div>
        <div class="card-body">


				<table id="sorted" class="table table-hover table-bordered">
				<thead>
				<tr>
							<th>Id</th>
			<th>Accounts id</th>
			<th>Name</th>
			<th>Pixel id</th>
			<th>Adtrust dsl</th>
			<th>Billing</th>
			<th>Amount</th>
			<th>Adaccount id</th>

				<th class="not">Action</th>
				</tr>
				</thead>

				<?php
				$ad_account = getAll("ad_account");
				if($ad_account) foreach ($ad_account as $ad_accounts):
					?>
					<tr>
		<td><?php echo $ad_accounts['id']?></td>
		<td><?php echo $ad_accounts['accounts_id']?></td>
		<td><?php echo $ad_accounts['name']?></td>
		<td><?php echo $ad_accounts['pixel_id']?></td>
		<td><?php echo $ad_accounts['adtrust_dsl']?></td>
		<td><?php echo $ad_accounts['billing']?></td>
		<td><?php echo $ad_accounts['amount']?></td>
		<td><?php echo $ad_accounts['adaccount_id']?></td>


						<td><a href="edit-ad_account.php?act=edit&id=<?php echo $ad_accounts['id']?>"><i class="fas fa-edit"></i></a> / <a href="save.php?act=delete&id=<?php echo $ad_accounts['id']?>&cat=ad_account" onclick="return navConfirm(this.href);"><i class="far fa-trash-alt"></i></a></td>
						</tr>
					<?php endforeach; ?>
					</table>

            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
    </div>
    <!-- /.card-body -->
</div>
<!-- /.card -->
<!-- general form elements disabled -->
</div>
<!-- /.card-body -->
<div class="card-footer">
    Альфа-тест
</div>
<!-- /.card-footer-->
</div>
<!-- /.card -->

<!-- /.modal -->
<div class="modal fade" id="modal-default">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Добавить аккаунт</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" action="save.php" enctype='multipart/form-data'>
                    <fieldset>
                        <input name="cat" type="hidden" value="accounts">
                        <input name="id" type="hidden" value="<?=$id?>">
                        <input name="act" type="hidden" value="add">

                        <label>Название</label>
                        <input class="form-control" type="text" name="name" value="<?=$accounts['name']?>" />

                        <label>Токен</label>
                        <textarea class="ckeditor form-control" name="token"><?=$accounts['token']?></textarea>


                        <!--label>Дневной лимит</label-->
                        <input class="form-control" type="hidden" name="adtrust_dsl" value="0" />
            </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                <button type="submit" class="btn btn-primary">Добавить</button>
            </div>
            </form>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
					<?php include "includes/footer.php";?>
				