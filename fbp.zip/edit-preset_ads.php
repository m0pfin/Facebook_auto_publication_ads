<?php
				include "includes/header.php";
				$data=[];

				$act = $_GET['act'];
				if($act == "edit"){
					$id = $_GET['id'];
					$preset_ads = getById("preset_ads", $id);
				}
				?>

				<form method="post" action="save.php" enctype='multipart/form-data'>
					<fieldset>
						<legend class="hidden-first">Add New Preset_ads</legend>
						<input name="cat" type="hidden" value="preset_ads">
						<input name="id" type="hidden" value="<?=$id?>">
						<input name="act" type="hidden" value="<?=$act?>">
				
							<label>Adset id</label>
							<input class="form-control" type="text" name="adset_id" value="<?=$preset_ads['adset_id']?>" /><br>
							
							<label>Name</label>
							<input class="form-control" type="text" name="name" value="<?=$preset_ads['name']?>" /><br>
							
							<label>Creative id</label>
							<input class="form-control" type="text" name="creative_id" value="<?=$preset_ads['creative_id']?>" /><br>
							
							<label>Title</label>
							<input class="form-control" type="text" name="title" value="<?=$preset_ads['title']?>" /><br>
							
							<label>Body</label>
							<input class="form-control" type="text" name="body" value="<?=$preset_ads['body']?>" /><br>
							
							<label>Object url</label>
							<textarea class="ckeditor form-control" name="object_url"><?=$preset_ads['object_url']?></textarea><br>
							
							<label>Image hash</label>
							<textarea class="ckeditor form-control" name="image_hash"><?=$preset_ads['image_hash']?></textarea><br>
							
							<label>Campgain id</label>
							<input class="form-control" type="text" name="campgain_id" value="<?=$preset_ads['campgain_id']?>" /><br>
							
							<label>Status</label>
							<input class="form-control" type="text" name="status" value="<?=$preset_ads['status']?>" /><br>
							<br>
					<input type="submit" value=" Save " class="btn btn-success">
					</form>
					<?php include "includes/footer.php";?>
				