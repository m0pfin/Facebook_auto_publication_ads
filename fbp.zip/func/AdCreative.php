<?php
/**
 * Created by PhpStorm.
 * User: m0pfin
 * Date: 13.06.2020
 * Time: 15:41
 */

ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require __DIR__ . '/../vendor/autoload.php';

use \Curl\Curl;

function createAdCreativeImages($id,$image_hash,$page_id, $token, $curl) {

    $data = array(

        'name' => 'Имя объявления блядское',
        'object_story_spec' => array(
            'link_data' => array(
                'image_hash' => $image_hash,
                'link' => 'https://whoiam.host/',
                'message' => 'AdCreativeTest message'
            ),
            'page_id' => $page_id
        ),
        'access_token' => $token,
    );

    $curl->setDefaultJsonDecoder($assoc = true);
    $curl->setHeader('Content-Type', 'application/json');
    $curl->post('https://graph.facebook.com/v7.0/'.$id.'/adcreatives', $data);

    echo "<pre>";
    var_dump($curl->response);
    echo "</pre>";

//    if ($curl->error) {
//        echo 'Error: ' . $curl->errorCode . ': ' . $curl->errorMessage . "\n";
//    } else {
//
//
//        //$response = json_decode(json_encode($curl->response),true); // преобразование строки в формате json в ассоциативный массив
//        //$ad_id = $response['id']; // получаем баланс
//        //return $ad_id; // Получаем ID созданной кампании
//    }
}

$curl = new Curl();

$id = 'act_569062560412369'; // ID рекламного акка
$page_id = '107775010939809';
$image_hash = 'bdfb42b2b466dee7daa39f0bed54f078';
$token = 'EAABsbCS1iHgBAGDMFbEU5HfwYzmLNoI3j6ZCTcOOmokP2PesMOa81d8RD7KrPAZAExLqUvl2iGyJXKZBAd3VgZAA5xIrpyrMnIslXuocs4o20kTaFRIC6tCE3ZAJKObKrZC2xOJZBggGga5JLaNY3ngbmNaTQAExBHopHR7ju545AZDZD';

echo createAdCreativeImages($id,$image_hash,$page_id, $token, $curl);