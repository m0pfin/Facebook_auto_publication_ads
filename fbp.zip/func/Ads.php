<?php
/**
 * Created by PhpStorm.
 * User: m0pfin
 * Date: 13.06.2020
 * Time: 15:41
 */


ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require __DIR__ . '/../vendor/autoload.php';

use \Curl\Curl;

/**
 * @param $id - рекламного акка
 * @param $adset_id - id Адсета
 * @param $token - из Ads Manager
 * @param $curl - класс php-curl
 */


function createAd($id,$adset_id, $token, $curl) {

    $data = array(

        'name' => 'Имя блядское объявления',
        'adset_id' => $adset_id,
        'creative' => array(
            'creative_id' => '23844855967870670',
            'title' => 'Заголовок',
            'body' => 'Текст объявления',
            'object_url' => 'https://facebook.com/mash',
            'image_hash' => 'bdfb42b2b466dee7daa39f0bed54f078'
        ),
        'status' => 'PAUSED',
        'access_token' => $token,
    );

    $curl->setDefaultJsonDecoder($assoc = true);
    $curl->setHeader('Content-Type', 'application/json');
    $curl->post('https://graph.facebook.com/v7.0/'.$id.'/ads', $data);

    echo "<pre>";
    var_dump($curl->response);
    echo "</pre>";

//    if ($curl->error) {
//        echo 'Error: ' . $curl->errorCode . ': ' . $curl->errorMessage . "\n";
//    } else {
//
//
//        //$response = json_decode(json_encode($curl->response),true); // преобразование строки в формате json в ассоциативный массив
//        //$ad_id = $response['id']; // получаем баланс
//        //return $ad_id; // Получаем ID созданной кампании
//    }
}

$curl = new Curl();

$id = 'act_569062560412369'; // ID рекламного акка
$adset_id = '23844820125710670';
$token = 'EAABsbCS1iHgBAGDMFbEU5HfwYzmLNoI3j6ZCTcOOmokP2PesMOa81d8RD7KrPAZAExLqUvl2iGyJXKZBAd3VgZAA5xIrpyrMnIslXuocs4o20kTaFRIC6tCE3ZAJKObKrZC2xOJZBggGga5JLaNY3ngbmNaTQAExBHopHR7ju545AZDZD';

echo createAd($id, $adset_id, $token, $curl);
