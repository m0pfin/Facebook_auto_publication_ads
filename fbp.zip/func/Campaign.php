<?php
/**
 * Created by PhpStorm.
 * User: m0pfin
 * Date: 11.06.2020
 * Time: 06:39
 */

ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require __DIR__ . '../vendor/autoload.php';

use \Curl\Curl;

/**
 * @param $id - рекламного акка
 * @param $token - из Ads Manager
 * @param $curl - класс php-curl
 */
function createCampgain($id, $token, $curl) {
        $curl->setHeader('Content-Type', 'application/json');
        $curl->post('https://graph.facebook.com/v7.0/'.$id.'/campaigns', array(
            'name' => 'Работай_Бля',
            'objective' => 'CONVERSIONS',
            'status' => 'ACTIVE',
            'special_ad_categories' => 'NONE',
            'access_token' => $token,
        ));

        if ($curl->error) {
            echo 'Error: ' . $curl->errorCode . ': ' . $curl->errorMessage . "\n";
        } else {
            //var_dump($curl->response);

            $response = json_decode(json_encode($curl->response),true); // преобразование строки в формате json в ассоциативный массив
            $campaign_id = $response['id']; // получаем баланс
            return $campaign_id; // Получаем ID созданной кампании
        }
    }

$curl = new Curl();
$id = 'act_569062560412369'; // ID рекламного акка
$token = 'EAABsbCS1iHgBAGDMFbEU5HfwYzmLNoI3j6ZCTcOOmokP2PesMOa81d8RD7KrPAZAExLqUvl2iGyJXKZBAd3VgZAA5xIrpyrMnIslXuocs4o20kTaFRIC6tCE3ZAJKObKrZC2xOJZBggGga5JLaNY3ngbmNaTQAExBHopHR7ju545AZDZD';

echo createCampgain($id, $token, $curl);
