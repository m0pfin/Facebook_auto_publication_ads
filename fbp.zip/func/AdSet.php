<?php
/**
 * Created by PhpStorm.
 * User: m0pfin
 * Date: 11.06.2020
 * Time: 08:24
 */

ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require __DIR__ . '/../vendor/autoload.php';

use \Curl\Curl;

/**
 * @param $id - рекламного акка
 * @param $campaign_id - id кампании
 * @param $token - из Ads Manager
 * @param $curl - класс php-curl
 */


function createAdSetConversion($id,$campaign_id, $token, $curl) {


    $data = array(
        'name' => 'AdSet_1',
        'daily_budget' => '50000',
        'start_time' => '2020-04-17T22:23:07-0700',
        'end_time' => '0',
        'bid_strategy' => 'LOWEST_COST_WITHOUT_CAP',
        'billing_event' => 'IMPRESSIONS',
        'optimization_goal' => 'OFFSITE_CONVERSIONS',
        'campaign_id' => $campaign_id,
        'targeting' => array(
            'geo_locations' => array(
                'countries' => array(
                    'FR'
                ),
            ),
        ),
        'promoted_object' => array(
            'custom_event_type' => 'LEAD',
            'pixel_id' => '2656807074586628'
        ),
        'status' => 'PAUSED',
        'access_token' => $token,
    );

    $curl->setDefaultJsonDecoder($assoc = true);
    $curl->setHeader('Content-Type', 'application/json');
    $curl->post('https://graph.facebook.com/v7.0/'.$id.'/adsets', $data);



    if ($curl->error) {
        echo 'Error: ' . $curl->errorCode . ': ' . $curl->errorMessage . "\n";
    } else {

        $response = json_decode(json_encode($curl->response),true); // преобразование строки в формате json в ассоциативный массив
        $adset_id = $response['id']; // получаем баланс
        return $adset_id; // Получаем ID созданного AdSet
    }
}

function createAdSetCliks($id,$campaign_id, $token, $curl) {

    $data = array(
        'name' => 'AdSet_ТЫБЛЯТЬ_ЗАРАБОТАЕШЬ',
        'daily_budget' => '50000',
        'start_time' => '2020-04-17T22:23:07-0700',
        'end_time' => '0',
        'bid_strategy' => 'LOWEST_COST_WITHOUT_CAP',
        'billing_event' => 'IMPRESSIONS',
        'optimization_goal' => 'LINK_CLICKS',
        'campaign_id' => $campaign_id,
        'targeting' => array(
            'geo_locations' => array(
                'countries' => array(
                    'FR'
                ),
            ),
        ),
        'promoted_object' => array(
            'custom_event_type' => 'LEAD',
            'pixel_id' => '2656807074586628'
        ),
        'status' => 'PAUSED',
        'access_token' => $token,
    );

    $curl->setDefaultJsonDecoder($assoc = true);
    $curl->setHeader('Content-Type', 'application/json');
    $curl->post('https://graph.facebook.com/v7.0/'.$id.'/adsets', $data);

    if ($curl->error) {
        echo 'Error: '
            . $curl->errorCode . ': ' . $curl->errorMessage . "\n";
    } else {

        //var_dump($curl->response);
        $response = json_decode(json_encode($curl->response),true); // преобразование строки в формате json в ассоциативный массив
        $adset_id = $response['id']; // получаем баланс
        return $adset_id; // Получаем ID созданной кампании
    }
}




$curl = new Curl();

$id = 'act_569062560412369'; // ID рекламного акка
$campaign_id = '23844809999810670';
$token = 'EAABsbCS1iHgBAGDMFbEU5HfwYzmLNoI3j6ZCTcOOmokP2PesMOa81d8RD7KrPAZAExLqUvl2iGyJXKZBAd3VgZAA5xIrpyrMnIslXuocs4o20kTaFRIC6tCE3ZAJKObKrZC2xOJZBggGga5JLaNY3ngbmNaTQAExBHopHR7ju545AZDZD';

echo createAdSetConversion($id,$campaign_id, $token, $curl);
