<?php
/**
 * Created by PhpStorm.
 * User: m0pfin
 * Date: 30.06.2020
 * Time: 05:53
 */
include "includes/header.php";
include "includes/functions.php";
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Автозалив 0.1</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Автозалив 0.1</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

        <!-- Default box -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Автозалив</h3>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                        <i class="fas fa-minus"></i></button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
                        <i class="fas fa-times"></i></button>
                </div>
            </div>
            <div class="card-body">
                <!-- right column -->
                <div class="col-md">
                    <!-- general form elements disabled -->

                        <!-- /.card-header -->
                        <div class="card-body">
                            <div role="form">
                                <form action="" id="callbacks">

                                <!-- select -->
                                <div class="row">
                                    <div class="col-sm-6">

                                        <div class="form-group">
                                            <label>Аккаунт</label>
                                            <select class="form-control" name="account">
                                             <?php
                                              $accounts = getAll("accounts");
                                              if($accounts) foreach ($accounts as $accountss):
                                              ?>
                                                <option value="<?php echo $accountss['token']?>"><?php echo $accountss['name']?></option>
                                             <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Пресет</label>
                                            <select class="form-control">
                                                <?php
                                                $preset = getAll("preset");
                                                if($preset) foreach ($preset as $presets):
                                                    ?>
                                                    <option value="<?php echo $presets['id']?>"><?php echo $presets['name_campaign']?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <!-- select end -->

                                <div class="row">

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Страница</label>
                                            <select class="form-control">
                                                <?php
                                                $proxy = getAll("proxy");
                                                if($proxy) foreach ($proxy as $proxys):
                                                    ?>
                                                    <option value="<?php echo $proxys['id']?>"><?php echo $proxys['ip']?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Карта</label>
                                            <select class="form-control">
                                                <?php
                                                $cards = getAll("cards");
                                                if($cards) foreach ($cards as $cardss):
                                                    ?>
                                                    <option value="<?php echo $cardss['id']?>"><?php echo $cardss['cardNumber']?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                    <div class="row">
                                        <div class="col-sm-6">
                                            <!-- text input -->
                                            <div class="form-group">
                                                <label>Ссылка</label>
                                                <input type="text" class="form-control" placeholder="https://site.ru/aOfokwi">
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="customFile">Креатив</label>

                                                <div class="custom-file">
                                                    <input type="file" class="custom-file-input" id="customFile">
                                                    <label class="custom-file-label" for="customFile">Выберите креатив</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                <div class="row">
                                    <div class="form-group">
                                        <label>Создать ФП</label>
                                        <input type="checkbox" name="my-checkbox" checked data-bootstrap-switch>
                                    </div>
                                </div>

                                <!-- input states -->
                                    <button type="submit" class="btn btn-primary">Залить</button>
                                </form>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                        <!-- general form elements disabled -->

                    <!-- /.card-body -->
                    <div class="card-footer">
                        Альфа-тест
                    </div>
                    <!-- /.card-footer-->
                </div>
                <!-- /.card -->

    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php include "includes/footer.php";?>
